import io, json, csv, re, zipfile
from pathlib import Path
from urllib.parse import urlparse
import pandas as pd
import streamlit as st
import os
from amazon_connector import fetch_product

st.set_page_config(page_title='跨平台商品采集工作台',layout='wide',page_icon='🛍️')
st.title('跨平台商品采集工作台 · MVP')
st.caption('SHEIN / Temu / Amazon ｜ 数据标准化 · SKC/SKU命名 · Excel和图片ZIP导出')
st.info('Amazon 可连接管理员部署的采集API；SHEIN/Temu仍支持数据导入，尚无实时接口。请遵守来源平台规则与图片授权要求。')

COLUMNS=['platform','product_id','url','title','category','currency','price','skc','sku','color','size','stock','main_image_url','detail_image_urls','variant_image_url']
ZH={'platform':'平台','product_id':'商品ID','url':'商品链接','title':'标题','category':'类目','currency':'货币','price':'价格','skc':'SKC','sku':'SKU','color':'颜色','size':'尺码/规格','stock':'库存','main_image_url':'主图链接','detail_image_urls':'详情图链接(分号分隔)','variant_image_url':'SKU颜色图链接'}

def clean(x):
    return re.sub(r'[\\/:*?"<>|\x00-\x1f]+','_',str(x or '').strip()).strip(' ._')[:90] or '未标注'

def rows_from_json(obj, platform):
    if isinstance(obj,dict):
        obj=obj.get('products',obj.get('items',obj.get('data',[obj])))
        if isinstance(obj,dict): obj=[obj]
    if not isinstance(obj,list): raise ValueError('JSON应为商品列表，或包含products/items/data数组')
    rows=[]
    for product in obj:
        if not isinstance(product,dict): continue
        variants=product.get('variants') or product.get('skus') or product.get('variations') or [{}]
        if isinstance(variants,dict): variants=variants.get('items') or variants.get('variants') or [{}]
        if not isinstance(variants,list): variants=[{}]
        price=product.get('price','')
        currency=product.get('currency','')
        if isinstance(price,dict): currency=price.get('currency',currency); price=price.get('amount',price.get('value',''))
        images=product.get('images',[])
        images=[i.get('link',i.get('url','')) if isinstance(i,dict) else str(i) for i in images] if isinstance(images,list) else []
        for v in variants:
            if not isinstance(v,dict): v={}
            color=v.get('color',product.get('color',''))
            size=v.get('size',product.get('size',''))
            rows.append({'platform':product.get('platform',platform),'product_id':product.get('product_id',product.get('asin',product.get('id',''))),'url':product.get('url',product.get('link','')),'title':product.get('title',product.get('name','')),'category':product.get('category',''),'currency':currency,'price':v.get('price',price),'skc':v.get('skc',product.get('skc','')),'sku':v.get('sku',v.get('asin','')),'color':color,'size':size,'stock':v.get('stock',product.get('stock','')),'main_image_url':product.get('main_image_url',images[0] if images else ''),'detail_image_urls':'; '.join(images[1:]),'variant_image_url':v.get('image_url',v.get('image',''))})
    return rows

with st.sidebar:
    st.header('导入配置')
    platform=st.selectbox('来源平台',['Amazon','SHEIN','Temu'])
    upload=st.file_uploader('导入商品 JSON 或 CSV',type=['json','csv'])
    st.caption('Excel使用UTF-8 CSV或JSON导入；支持后续编辑字段。')
    st.download_button('下载空白CSV模板',','.join(COLUMNS)+'\n','products_template.csv','text/csv')

st.subheader('⓪ Amazon API商品查询（需管理员配置）')
api_url = os.getenv('AMAZON_API_BASE_URL', '')
try:
    api_url = st.secrets.get('AMAZON_API_BASE_URL', api_url)
    api_key = st.secrets.get('AMAZON_API_KEY', os.getenv('AMAZON_API_KEY', ''))
except Exception:
    api_key = os.getenv('AMAZON_API_KEY', '')
if not api_url:
    st.caption('未配置Amazon API服务器：目前不能进行实时查询，可继续导入CSV/JSON。')
else:
    with st.form('amazon_lookup'):
        asin_text = st.text_area('Amazon ASIN或商品链接（一行一个，最多10个）', placeholder='B07QSFHT27')
        do_fetch = st.form_submit_button('查询Amazon商品')
    if do_fetch:
        values = [x.strip() for x in asin_text.splitlines() if x.strip()][:10]
        fetched=[];errors=[]
        for value in values:
            try:
                item=fetch_product(value,api_url,api_key)
                item['platform']='Amazon'
                fetched.append(item)
            except Exception as exc:
                errors.append(f'{value}: {exc}')
        st.session_state['amazon_records']=rows_from_json(fetched,'Amazon') if fetched else []
        st.session_state['amazon_errors']=errors
    for err in st.session_state.get('amazon_errors',[]):
        st.warning(err)

if upload:
    try:
        if upload.name.lower().endswith('.json'): records=rows_from_json(json.load(upload),platform)
        else: records=list(csv.DictReader(io.StringIO(upload.getvalue().decode('utf-8-sig'))))
        df=pd.DataFrame(records)
        for c in COLUMNS:
            if c not in df:df[c]=''
        df=df[COLUMNS].fillna('')
    except Exception as e:
        st.error(f'导入失败：{e}');st.stop()
else:
    df=pd.DataFrame(st.session_state.get('amazon_records') or [{c:'' for c in COLUMNS}])
    for c in COLUMNS:
        if c not in df:df[c]=''
    df=df[COLUMNS].fillna('')

st.subheader('① 商品资料审核与编辑')
edit=st.data_editor(df,column_config={c:st.column_config.TextColumn(ZH[c]) for c in COLUMNS},num_rows='dynamic',hide_index=True,use_container_width=True)
edit=edit.fillna('')

def make_base(row, mode):
    ident=clean(row.get('product_id') or row.get('skc') or row.get('title') or '商品')
    color=clean(row.get('color') or '通用色')
    size=clean(row.get('size') or '通用规格')
    if mode=='按SKC颜色': return f'{ident}_{color}'
    return f'{ident}_{color}_{size}'

st.subheader('② 图片命名与归档')
mode=st.radio('命名模式',['按SKC颜色','按SKU颜色+尺码'],horizontal=True)
photos=st.file_uploader('上传已获授权的商品图片（支持多选）',type=['jpg','jpeg','png','webp'],accept_multiple_files=True)
photo_map={p.name:p for p in photos or []}
photo_names=list(photo_map)
selected=st.selectbox('对应商品行',list(range(len(edit))),format_func=lambda i:f'第{i+1}行 · {str(edit.iloc[i].get("title", ""))[:45]}' if len(edit) else '无商品') if len(edit) else None
kind=st.selectbox('图片类型',['SKU颜色图','详情图','主图'])
chosen=st.multiselect('选择要归档的图片',photo_names,default=photo_names)
if 'assignments' not in st.session_state: st.session_state.assignments=[]
if st.button('添加图片对应关系',disabled=(selected is None or not chosen)):
    for name in chosen:st.session_state.assignments.append({'row':selected,'kind':kind,'name':name})
    st.success('已记录图片归属')
if st.session_state.assignments:
    st.dataframe(pd.DataFrame(st.session_state.assignments),hide_index=True)
    if st.button('清空图片对应关系'): st.session_state.assignments=[];st.rerun()

st.subheader('③ 导出')
out=edit.rename(columns=ZH)
output=io.BytesIO()
with pd.ExcelWriter(output,engine='xlsxwriter') as writer:
    out.to_excel(writer,index=False,sheet_name='商品SKU明细')
    sheet=writer.sheets['商品SKU明细'];sheet.freeze_panes(1,0);sheet.autofilter(0,0,max(len(out),1),len(out.columns)-1)
    head=writer.book.add_format({'bold':True,'bg_color':'#17365D','font_color':'white','text_wrap':True})
    for i,col in enumerate(out.columns):
        sheet.write(0,i,col,head);sheet.set_column(i,i,23 if i not in [2,3,12,13,14] else 48)
st.download_button('下载Excel商品明细',output.getvalue(),file_name='跨平台商品SKU明细.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

if photo_map and st.session_state.assignments:
    buff=io.BytesIO(); manifest=[]; counters={}
    with zipfile.ZipFile(buff,'w',zipfile.ZIP_DEFLATED) as z:
        for item in st.session_state.assignments:
            if item['name'] not in photo_map or item['row']>=len(edit):continue
            row=edit.iloc[item['row']]
            prefix=make_base(row,mode)
            key=(prefix,item['kind']); counters[key]=counters.get(key,0)+1
            ext=Path(item['name']).suffix.lower() or '.jpg'
            name=f'{clean(row.get("platform") or platform)}/{clean(row.get("product_id") or "未编号")}/{clean(item["kind"] )}/{prefix}_{counters[key]:02d}{ext}'
            z.writestr(name,photo_map[item['name']].getvalue())
            manifest.append({'源文件':item['name'],'归档名称':name,'商品行':item['row']+1})
        z.writestr('图片清单.csv','\ufeff'+pd.DataFrame(manifest).to_csv(index=False))
    st.download_button('下载已命名图片ZIP',buff.getvalue(),'SKC_SKU_图片归档.zip',mime='application/zip')
else: st.caption('上传图片并添加图片归属后，可生成图片归档ZIP。')

with st.expander('采集适配器接入说明'):
    st.markdown('''- Amazon：通过环境变量 AMAZON_API_BASE_URL 接入独立运行的 https://github.com/omkarcloud/amazon-scraper API，支持单个或批量ASIN（最多10个）查询。商品变体的详细拆分还需联调。\n- SHEIN：待检查现有项目许可、数据结构和稳定性。\n- Temu：待验证可靠、合规的数据源。\n- 当前不会绕过登录、验证码或平台反采集措施。图片仅处理用户已获得合法使用权的文件。''')
