"""Amazon adapter for a separately deployed omkarcloud/amazon-scraper API."""
import re
from urllib.parse import urlparse
import requests

ASIN = re.compile(r'^[A-Z0-9]{10}$')

def extract_asin(value):
    value = value.strip()
    if ASIN.fullmatch(value.upper()):
        return value.upper()
    match = re.search(r'/(?:dp|gp/product)/([A-Z0-9]{10})(?:[/?]|$)', value, re.I)
    if match and urlparse(value).hostname and 'amazon.' in urlparse(value).hostname.lower():
        return match.group(1).upper()
    raise ValueError('请输入10位ASIN或Amazon /dp/ 商品链接')

def fetch_product(asin, base_url, api_key=None, timeout=25):
    """Endpoint originates solely from deployment configuration, never imported merchandise."""
    if not base_url or not base_url.startswith(('https://','http://')):
        raise ValueError('管理员尚未配置 AMAZON_API_BASE_URL')
    headers = {'Authorization': f'Bearer {api_key}'} if api_key else {}
    response = requests.get(base_url.rstrip('/')+'/products/details', params={'product':extract_asin(asin)}, headers=headers, timeout=timeout)
    response.raise_for_status()
    data = response.json()
    if not isinstance(data,dict):
        raise ValueError('API返回不是JSON对象')
    if 'data' in data and isinstance(data['data'],dict):
        data=data['data']
    if not data.get('asin') and not data.get('title'):
        raise ValueError('API未返回有效商品；请检查API服务和ASIN')
    return data
