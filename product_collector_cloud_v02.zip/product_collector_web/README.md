# SHEIN / Temu / Amazon 商品采集工作台（MVP）

## 当前能做什么
- 网页界面导入 CSV 或 JSON 商品信息并手动修改
- 将商品展开为 SKU 明细；识别部分通用 JSON 字段
- 关联已上传的图片与商品行，按 SKC 颜色或 SKU 颜色+尺码命名并生成 ZIP
- 下载带筛选、冻结标题行的 Excel

**当前不提供在线采集、站点登录、抓取、远程图片下载、自动发布上新。** GitHub 采集器是待验证的后续接口，不在此包内。

## 本地运行
```bash
pip install -r requirements.txt
streamlit run app.py
```
打开命令行给出的地址（通常 http://localhost:8501 ）。

## 云端部署
把本目录上传到你自己的私有 GitHub 仓库，使用支持 Python 的 Streamlit 部署环境，启动命令为 `streamlit run app.py --server.address 0.0.0.0 --server.port $PORT`（具体端口变量按平台调整）。公网部署前必须先增加身份认证、文件大小和上传限制、持久化存储与权限控制；不要公开真实商品数据或账号密钥。Streamlit 多人实例上的会话上传是临时的，不代表持久存储。

## 字段格式
CSV列包括 platform,product_id,url,title,category,currency,price,skc,sku,color,size,stock,main_image_url,detail_image_urls,variant_image_url。
JSON 支持商品数组，或者 `products` / `items` / `data` 数组；常见商品字段支持 `asin`, `link`, `images`, `variants` 等。

## 接下来
1. 为各站点选择来源渠道并核对服务条款与许可。
2. 实测每个站点不同类目的 SKC → SKU → 图片映射。
3. 加入后端采集作业、任务队列、进度监控、错误记录和去重。
4. 增加登录授权与数据库，再部署生产网页版。

## 云端部署（v0.2）

1. 在 GitHub 创建私人仓库，将本文件夹内 `app.py`、`amazon_connector.py`、`requirements.txt`、`.gitignore` 上传仓库根目录。
2. 打开 https://share.streamlit.io ，使用 GitHub 授权，Create app，选仓库/main、主文件 `app.py`。设置你喜欢的可用 `*.streamlit.app` 子域名。
3. 未配置 Amazon API 时，网页可进行 CSV/JSON 导入、图片归档与 Excel 导出。
4. 若需实时 Amazon ASIN 查询，单独在可运行 Python 服务的云服务器部署 https://github.com/omkarcloud/amazon-scraper （遵循其 README 安装并启动 `python run.py`）；用 HTTPS 反向代理暴露有认证和访问限制的 API。不要直接公开无验证的8000端口。
5. 在 Streamlit App Settings → Secrets 配置 `AMAZON_API_BASE_URL="https://<受保护的API地址>"`。若你使用自己的API网关支持 Bearer 验证，可以另外配置 `AMAZON_API_KEY`。
6. 回到网页，填写 Amazon ASIN 或商品链接，每次最多10个，点击查询。将结果人工核对后导出。

**部署限制**：这里仅提供部署包，未代替用户登录GitHub/云平台完成上线；Amazon API尚未实际部署或线上连通性验证。仓库示例返回的 `variations` 是汇总对象，不能自动当作完整 SKU 列表；SKC/SKU关系需要后续联合 `/products/variations` 接口验证。SHEIN 和 Temu 的实时采集还未接入。临时上传的数据存放在用户会话中，不适合作为长期云端商品资料库；未来需要数据库和对象存储。
